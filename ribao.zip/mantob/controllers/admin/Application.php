<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Mantob Website Management System
 *
 * @since		version 2.3.1
 * @author		mantob <kefu@mantob.com>
 * @license     http://www.mantob.com/license
 * @copyright   Copyright (c) 2013 - 9999, mantob.Com, Inc.
 */
	
class Application extends M_Controller {

    /**
     * 构造函数
     */
    public function __construct() {
        parent::__construct();
		$this->template->assign('menu', $this->get_menu(array(
		    lang('219') => 'admin/application/index',
            lang('001') => 'admin/home/cache',
		    lang('220') => 'admin/application/store',
		)));
		$this->load->model('application_model');
    }
	
	/**
     * 管理
     */
    public function index() {
	
		$store = $data = array();
		$local = man_dir_map(FCPATH.'app/', 1); // 搜索本地应用
		$application = $this->application_model->get_data(); // 库中已安装应用
		
		if ($local) {
			foreach ($local as $dir) {
				if (is_file(FCPATH.'app/'.$dir.'/config/app.php')) {
					if (isset($application[$dir])) {
						$config = $data[1][$dir] = array_merge($application[$dir], require FCPATH.'app/'.$dir.'/config/app.php');
						if ($config['key']) {
							if (isset($store[$config['key']])) {
								if (version_compare($config['version'], $store[$config['key']], '<')) {
                                    $store[$config['key']] = $config['version'];
                                }
							} else {
								$store[$config['key']] = $config['version'];
							}
						}
					} else {
						$data[0][$dir] = require FCPATH.'app/'.$dir.'/config/app.php';
					}
				}
			}
		}
		
		$this->template->assign(array(
			'list' => $data,
			'store' => man_base64_encode(man_array2string($store)),
		));
		$this->template->display('application_index.html');
    }
    
	/**
     * 禁用/可用
     */
    public function disabled() {
	
		if ($this->is_auth('admin/application/config')) {
			$id = (int)$this->input->get('id');
			$_data = $this->db
						  ->select('disabled')
						  ->where('id', $id)
						  ->limit(1)
						  ->get('application')
						  ->row_array();
			$this->db
				 ->where('id', $id)
				 ->update('application', array('disabled' => ($_data['disabled'] == 1 ? 0 : 1)));
            $this->clear_cache('app');
		}
		
		exit(man_json(1, lang('014')));
    }
	
	/**
     * 删除
     */
    public function delete() {

		$dir = $this->input->get('dir');

        $this->load->helper('file');
		delete_files(FCPATH.'app/'.$dir.'/', TRUE);

		if (is_dir(FCPATH.'app/'.$dir.'/')) {
            @rmdir(FCPATH.'app/'.$dir.'/');
        }

        if (is_dir(FCPATH.'app/'.$dir.'/')) {
            $this->admin_msg(lang('352'));
        }

        // 删除菜单
        $this->db->where('mark', 'app-'.$dir)->delete('admin_menu');
        $this->db->where('mark', 'app-'.$dir)->delete('member_menu');

        $this->clear_cache('app');
		$this->admin_msg(lang('000'), man_url('application/index'), 1);
    }
	
	/**
     * 商店
     */
    public function store() {
	
		$data = array();
		$local = man_dir_map(FCPATH.'app/', 1); // 搜索本地应用
		if ($local) {
			foreach ($local as $dir) {
				if (is_file(FCPATH.'app/'.$dir.'/config/app.php')) {
					$config = require FCPATH.'app/'.$dir.'/config/app.php';
					if ($config['key']) {
						$data[$config['key']] = $config['version'];
					}
				}
			}
		}
		
$url = 'http://store.mantob.com/index.php?c=category&id=1&action=application&param='.man_base64_encode(man_array2string(array(
			'site' => SITE_URL,
			'name' => SITE_NAME,
			'data' => $data,
			'admin' => SELF,
			'version' => MAN_VERSION_ID,
		)));
		$this->template->assign(array(
			'url' => $url,
		));
		$this->template->display('online.html');
    }
	
	/**
     * 云端下载程序
     */
    public function down() {
    	
    	$dir = $this->input->get('dir');
		if (is_dir(FCPATH.'app/'.$dir.'/')) {
            $this->admin_msg('目录（/app/'.$dir.'/）已经存在');
        }
		
    	$data = man_catcher_data(urldecode($this->input->get('id')));
    	if (!$data) {
            $this->admin_msg('对不起，您的服务器不支持远程下载');
        }
    	
    	$save = FCPATH.'cache/down/app.zip';
    	$check = FCPATH.'cache/down/app/';
		if (!@file_put_contents($save, $data)) {
            $this->admin_msg('目录（/cache/down/）没有写入权限');
        }
		
		// 载入解压缩类
		$this->load->helper('file');
		$this->load->library('Pclzip');

        // 文件安全性检测
        $this->pclzip->PclFile($save);
        $content = $this->pclzip->listContent();
        if (!$content) {
            $this->admin_msg('文件下载不完整或者已经损坏！<br>请检查网站目录权限或者联系应用开发者。');
        }
        foreach ($content as $t) {
            if (strpos($t['stored_filename'], '..') !== FALSE ||
                strpos($t['stored_filename'], '/') === 0) {
                $this->admin_msg('含有非法名称的文件：'.basename($t['stored_filename']));
            }
        }
        unset($content);

        // 开始解压文件
		if ($this->pclzip->extract(PCLZIP_OPT_PATH, $check, PCLZIP_OPT_REPLACE_NEWER) == 0) {
			@unlink($save);
			delete_files(FCPATH.'cache/down/', TRUE);
			$this->admin_msg("Error : " . $this->pclzip->errorInfo(true));
		}
		
		// 检查版本文件
    	if (!is_file($check.'config/app.php') || !filesize($check.'config/app.php')) {
			delete_files(FCPATH.'cache/down/', TRUE);
    		$this->admin_msg('文件不完整，请重试');
    	}
    	
    	// 覆盖至网站根目录
    	$this->pclzip->extract(PCLZIP_OPT_PATH, FCPATH.'app/'.$dir.'/', PCLZIP_OPT_REPLACE_NEWER);
    	
    	delete_files(FCPATH.'cache/down/', TRUE);
    	
		$this->admin_msg('下载成功，即将为您跳转到应用中心', man_url('application/index'), 1);
    }
	
	/**
     * 更新
     */
    public function update() {
	
		$key = 0;
		$dir = $this->input->get('id');
		if (is_file(FCPATH.'app/'.$dir.'/config/app.php')) {
			$config = require FCPATH.'app/'.$dir.'/config/app.php';
			$key = (int)$config['key'];
		}
		if (!$key) {
            $this->admin_msg('此应用无法在线更新（key不存在）');
        }
		
		$url = 'http://store.mantob.com/index.php?c=down&m=update&action=application&param='.man_base64_encode(man_array2string(array(
			'site' => SITE_URL,
			'name' => SITE_NAME,
			'data' => array(
				'id' => $key,
				'dir' => $dir,
				'version' => $config['version']
			),
			'admin' => SELF,
			'domain' => SITE_URL,
			'version' => MAN_VERSION_ID,
		)));
		$this->template->assign(array(
			'url' => $url,
		));
		$this->template->display('online.html');
    }
	
	/**
     * 升级程序
     */
    public function upgrade() {
    	
    	$key = (int)$this->input->get('key');
    	$dir = $this->input->get('dir');
		if (is_file(FCPATH.'app/'.$dir.'/config/app.php')) {
			$config = require FCPATH.'app/'.$dir.'/config/app.php';
			if ((int)$config['key'] != $key) {
                $this->admin_msg('此应用无法在线升级，key不匹配');
            }
		} else {
			 $this->admin_msg('此应用无法在线升级，目录（/app/'.$dir.'/）不存在');
		}
		
    	$data = man_catcher_data(urldecode($this->input->get('id')));
    	if (!$data) {
            $this->admin_msg('对不起，您的服务器不支持远程下载');
        }
    	
    	$save = FCPATH.'cache/down/app.zip';
    	$check = FCPATH.'cache/down/app/';
		if (!@file_put_contents($save, $data)) {
            $this->admin_msg('目录/cache/down/没有写入权限');
        }
		
		// 解压缩文件
		$this->load->helper('file');
		$this->load->library('Pclzip');

        // 文件安全性检测
        $this->pclzip->PclFile($save);
        $content = $this->pclzip->listContent();
        if (!$content) {
            $this->admin_msg('文件下载不完整或者已经损坏！<br>请检查网站目录权限或者联系应用开发者。');
        }
        foreach ($content as $t) {
            if (strpos($t['stored_filename'], '..') !== FALSE ||
                strpos($t['stored_filename'], '/') === 0) {
                $this->admin_msg('含有非法名称的文件：'.basename($t['stored_filename']));
            }
        }
        unset($content);

        // 开始解压文件
		if ($this->pclzip->extract(PCLZIP_OPT_PATH, $check, PCLZIP_OPT_REPLACE_NEWER) == 0) {
			@unlink($save);
			delete_files(FCPATH.'cache/down/', TRUE);
			$this->admin_msg("Error : " . $this->pclzip->errorInfo(true));
		}
		
		// 检查版本文件
    	if (!is_file($check.'config/app.php') || !filesize($check.'config/app.php')) {
			delete_files(FCPATH.'cache/down/', TRUE);
    		$this->admin_msg('升级文件不完整，请重试');
    	}
    	
    	// 覆盖至网站目录
    	$this->pclzip->extract(PCLZIP_OPT_PATH, FCPATH.'app/'.$dir, PCLZIP_OPT_REPLACE_NEWER);
    	delete_files(FCPATH.'cache/down/', TRUE);
    	
    	// 运行SQL语句
    	if (is_file(FCPATH.'app/'.$dir.'/update.sql')) {
    		$sql = file_get_contents(FCPATH.'app/'.$dir.'/update.sql');
			$sql = str_replace('{dbprefix}', $this->db->dbprefix, $sql);
			$this->sql_query($sql);
			@unlink(FCPATH.'app/'.$dir.'/update.sql');
    	}
    	
    	//检查update控制器
		if (is_file(FCPATH.'app/'.$dir.'/controllers/admin/Update.php')) {
            $this->admin_msg('正在升级数据，请稍候...', man_url($dir.'/update/index'), 2);
        }
		
		$this->admin_msg('升级完成，请重新检测一次版本', man_url('application/index'), 1);
    }

    /**
     * 缓存
     */
    public function cache() {
        $this->application_model->cache();
        (int)$_GET['admin'] or $this->admin_msg(lang('000'), isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '', 1);
    }
}