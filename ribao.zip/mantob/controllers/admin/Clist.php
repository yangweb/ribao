<?php

/**
 * Mantob Website Management System
 *
 * @since		version 2.3.1
 * @author		mantob <kefu@mantob.com>
 * @license     http://www.mantob.com/license
 * @copyright   Copyright (c) 2013 - 9999, mantob.Com, Inc.
 */

class Clist extends M_Controller {

    /**
     * 高级授权用户专属功能
     */
    public function __construct() {
        parent::__construct();
    }


}