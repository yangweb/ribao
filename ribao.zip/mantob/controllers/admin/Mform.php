<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Mantob Website Management System
 *
 * @since		version 2.0.5
 * @author		mantob <kefu@mantob.com>
 * @license     http://www.mantob.com/license
 * @copyright   Copyright (c) 2013 - 9999, mantob.Com, Inc.
 */
	
class Mform extends M_Controller {

	public $dir;
	public $link;
	public $table;

    /**
     * 构造函数
     */
    public function __construct() {
        parent::__construct();
		$this->dir = $this->input->get('dir');
		$module = $this->get_cache('module-'.SITE_ID.'-'.$this->dir);
		if (!$module) {
            $this->admin_msg(lang('100'));
        }
		$this->link = $this->site[SITE_ID];
		$this->table = $this->db->dbprefix(SITE_ID.'_'.$this->dir.'_form');
		$this->template->assign('menu', $this->get_menu(array(
		    man_lang('330', $module['name']) => 'admin/mform/index/dir/'.$this->dir,
		    lang('add') => 'admin/mform/add/dir/'.$this->dir,
		    lang('334') => 'admin/mform/export/dir/'.$this->dir,
		    lang('333') => 'admin/mform/import/dir/'.$this->dir,
		)));
		$this->load->model('mform_model');
    }
	
	/**
     * 管理
     */
    public function index() {
		$this->template->assign(array(
			'dir' => $this->dir,
			'list' => $this->link->get($this->table)->result_array()
		));
		$this->template->display('mform_index.html');
    }
	
	/**
     * 添加
     */
    public function add() {
	
		if (IS_POST) {
			$result = $this->mform_model->add($this->input->post('data', TRUE));
			if ($result === FALSE) {
				$this->admin_msg(lang('000'), man_url('mform/index', array('dir' => $this->dir)), 1);
			} else {
				$this->admin_msg($result);
			}
		}
		
		$this->template->assign(array(
			'data' => array()
		));
		$this->template->display('mform_add.html');
    }
	
	/**
     * 修改
     */
    public function edit() {
	
		$id = (int)$this->input->get('id');
		$data = $this->link
					 ->where('id', $id)
					 ->limit(1)
					 ->get($this->table)
					 ->row_array();
		if (!$data) {
            $this->admin_msg(lang('019'));
        }
		
		if (IS_POST) {
			$data = $this->input->post('data', TRUE);
			$this->link->where('id', $id)->update($this->table, array(
				'name' => $data['name'],
				'setting' => man_array2string($data['setting']),
				'permission' => man_array2string($data['permission']),
			));
			$this->admin_msg(lang('000'), man_url('mform/index', array('dir' => $this->dir)), 1);
		}
		
		$data['setting'] = man_string2array($data['setting']);
		$data['permission'] = man_string2array($data['permission']);
		
		$this->template->assign(array(
			'data' => $data,
		));
		$this->template->display('mform_add.html');
    }
	
	/**
     * 禁用/可用
     */
    public function disabled() {
		if ($this->is_auth('mform/edit')) {
			$id = (int)$this->input->get('id');
			$data = $this->link
						 ->select('disabled')
						 ->where('id', $id)
						 ->limit(1)
						 ->get($this->table)
						 ->row_array();
			$value = $data['disabled'] == 1 ? 0 : 1;
			$this->link
				 ->where('id', $id)
				 ->update($this->table, array('disabled' => $value));
		}
		exit(man_json(1, lang('014')));
    }
	
	// 导出表单
	public function export() {
		if ($this->input->get('todo')) {
			$this->load->model('module_model');
			$this->module_model->export_form($this->dir);
			$this->template->assign('size', man_format_file_size(filesize(FCPATH.$this->dir.'/config/form.php')));
			$this->template->display('mform_export.html');
		} else {
			$this->admin_msg(lang('332'), man_url('mform/export', array('dir' => $this->dir, 'todo' => 1)), 2);
		}
	}
	
	// 导入表单
	public function import() {
		if (IS_POST) {
			$file = FCPATH.$this->dir.'/config/form.php';
			if (!is_file($file)) {
                $this->admin_msg(man_lang('335', $this->dir.'/config/form.php'));
            }
			$this->load->model('module_model');
			if ($this->module_model->import_form($this->dir)) {
				$this->admin_msg(lang('014'), man_url('mform/index', array('dir' => $this->dir)), 2);
			} else {
				$this->admin_msg(lang('336'));
			}
		}
		$this->template->assign('size', man_format_file_size(@filesize(FCPATH.$this->dir.'/config/form.php')));
		$this->template->display('mform_import.html');
	}
	
	/**
     * 删除
     */
    public function del() {
		$this->mform_model->del((int)$this->input->get('id'));
		$this->admin_msg(lang('000'), man_url('mform/index', array('dir' => $this->dir)), 1);
	}

}