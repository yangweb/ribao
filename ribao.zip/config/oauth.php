<?php

/**
 * mantob Website Management System
 * 
 * @since			version 2.0.3
 * @author			mantob <kefu@mantob.com>
 * @license     	http://www.mantob.com/license
 * @copyright		Copyright (c) 2013 - 9999, mantob.Com, Inc.
 */

/**
 * OAuth2授权登录
 */

return array (
    'sina' => 
    array (
        'key' => '123456',
        'use' => 0,
        'name' => '新浪微博',
        'icon' => 'sina',
        'secret' => 'bb0b65e3df315ba3e8c496bbbaa0',
    ),
    'qq' => 
    array (
        'key' => '123456',
        'use' => 0,
        'name' => 'QQ',
        'icon' => 'qq',
        'secret' => 'bb7116e7767bafc94308d48cf3',
    ),
    'baidu' => 
    array (
        'key' => '123456',
        'use' => 0,
        'name' => '百度',
        'icon' => 'baidu',
        'secret' => 'bb5CULF2p5lrkNYKn0nvsWbR88',
    ),
    163 => 
    array (
        'key' => '123456',
        'use' => 0,
        'name' => '网易微博',
        'icon' => '163',
        'secret' => 'bbjhbEWM1qHcVu58N2Mh0E58TsJ',
    ),
    360 => 
    array (
        'key' => '123456',
        'use' => 0,
        'name' => '360',
        'icon' => '360',
        'secret' => 'bb6a1170ed3fd5a8c8dc5958',
    ),
    'google' => 
    array (
        'key' => '123456',
        'use' => 0,
        'name' => 'Google',
        'icon' => 'google',
        'secret' => 'bb6a1170ed3fd5a8c8dc595808',
    ),
    'sohu' => 
    array (
        'key' => '123456',
        'use' => 0,
        'name' => '搜狐微博',
        'icon' => 'sohu',
        'secret' => 'bb6a1170ed3fd5a8c8dc5958',
    ),
    'taobao' => 
    array (
        'key' => '123456',
        'use' => 0,
        'name' => '淘宝网',
        'icon' => 'taobao',
        'secret' => 'bb6a1170ed3fd5a8c8dc595884281108',
    ),
);