<?php

/**
 * Mantob Website Management System
 * 
 * @since			version 2.0.3
 * @author			mantob <kefu@mantob.com>
 * @license     	http://www.mantob.com/license
 * @copyright		Copyright (c) 2013 - 9999, mantob.Com, Inc.
 */

/**
 * 短信配置文件
 */

return array(

	'uid'   => 11,
	'key'   => 'c6b2029868449ef241147efa6ee6c606',

);