<?php

/**
 * Mantob Website Management System
 * 
 * @since			version 2.0.0
 * @author			mantob <kefu@mantob.com>
 * @license     	http://www.mantob.com/license
 * @copyright		Copyright (c) 2013 - 9999, mantob.Com, Inc.
 */

/**
 * 模块配置
 */

return array(

	'key'			=> 1,
	'name'			=> '议题',
	'author'		=> 'mantob团队',
	'version'		=> '1.2',

);