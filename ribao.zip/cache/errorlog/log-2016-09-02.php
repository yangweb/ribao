<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-09-02 08:55:00 --> 钩子调用文件（G:\code2016\mantou\serve\ribao/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-09-02 08:56:18 --> 钩子调用文件（G:\code2016\mantou\serve\ribao/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-09-02 08:57:27 --> 钩子调用文件（G:\code2016\mantou\serve\ribao/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-09-02 09:30:16 --> Severity: Parsing Error --> syntax error, unexpected '<' G:\code2016\mantou\serve\ribao\cache\templates\14f0c40492da1363938df782449f0750.cache.php 3
ERROR - 2016-09-02 09:31:22 --> Severity: Parsing Error --> syntax error, unexpected '<' G:\code2016\mantou\serve\ribao\cache\templates\14f0c40492da1363938df782449f0750.cache.php 3
ERROR - 2016-09-02 09:35:03 --> Severity: Parsing Error --> syntax error, unexpected '<' G:\code2016\mantou\serve\ribao\cache\templates\14f0c40492da1363938df782449f0750.cache.php 3
ERROR - 2016-09-02 09:38:07 --> Severity: Parsing Error --> syntax error, unexpected '<' G:\code2016\mantou\serve\ribao\cache\templates\14f0c40492da1363938df782449f0750.cache.php 3
ERROR - 2016-09-02 09:38:33 --> Severity: Parsing Error --> syntax error, unexpected '<' G:\code2016\mantou\serve\ribao\cache\templates\14f0c40492da1363938df782449f0750.cache.php 3
ERROR - 2016-09-02 09:57:30 --> Severity: Parsing Error --> syntax error, unexpected '<' G:\code2016\mantou\serve\ribao\cache\templates\d59ee478a2f08f6f416ab64ba3c539f2.cache.php 3
ERROR - 2016-09-02 10:21:11 --> 钩子调用文件（G:\code2016\mantou\serve\ribao/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-09-02 10:21:45 --> 钩子调用文件（G:\code2016\mantou\serve\ribao/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-09-02 10:24:30 --> 钩子调用文件（G:\code2016\mantou\serve\ribao/mantob/hooks/module_hooks.php）的不存在
