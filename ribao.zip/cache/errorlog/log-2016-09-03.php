<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-09-03 11:28:36 --> Severity: Parsing Error --> syntax error, unexpected ')' G:\code2016\mantou\serve\ribao\cache\templates\a7f11648a88d45cedee1abdc0b8f1ff7.cache.php 9
ERROR - 2016-09-03 11:28:47 --> Severity: Parsing Error --> syntax error, unexpected ')' G:\code2016\mantou\serve\ribao\cache\templates\a7f11648a88d45cedee1abdc0b8f1ff7.cache.php 17
ERROR - 2016-09-03 11:28:59 --> Severity: Parsing Error --> syntax error, unexpected ')' G:\code2016\mantou\serve\ribao\cache\templates\a7f11648a88d45cedee1abdc0b8f1ff7.cache.php 17
ERROR - 2016-09-03 11:31:19 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) G:\code2016\mantou\serve\ribao\cache\templates\a7f11648a88d45cedee1abdc0b8f1ff7.cache.php 9
ERROR - 2016-09-03 11:31:41 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) G:\code2016\mantou\serve\ribao\cache\templates\a7f11648a88d45cedee1abdc0b8f1ff7.cache.php 9
ERROR - 2016-09-03 11:39:07 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) G:\code2016\mantou\serve\ribao\cache\templates\a7f11648a88d45cedee1abdc0b8f1ff7.cache.php 9
ERROR - 2016-09-03 11:39:41 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) G:\code2016\mantou\serve\ribao\cache\templates\a7f11648a88d45cedee1abdc0b8f1ff7.cache.php 9
ERROR - 2016-09-03 11:40:00 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) G:\code2016\mantou\serve\ribao\cache\templates\a7f11648a88d45cedee1abdc0b8f1ff7.cache.php 9
ERROR - 2016-09-03 11:41:07 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) G:\code2016\mantou\serve\ribao\cache\templates\a7f11648a88d45cedee1abdc0b8f1ff7.cache.php 9
ERROR - 2016-09-03 11:55:23 --> Severity: Parsing Error --> syntax error, unexpected ')' G:\code2016\mantou\serve\ribao\cache\templates\a7f11648a88d45cedee1abdc0b8f1ff7.cache.php 17
ERROR - 2016-09-03 12:26:26 --> Severity: Error --> Call to undefined function man_down_file2() G:\code2016\mantou\serve\ribao\cache\templates\ac11e6a7b3c094d4e5e65089aa98dd23.cache.php 28
ERROR - 2016-09-03 12:58:21 --> 钩子调用文件（G:\code2016\mantou\serve\ribao/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-09-03 13:38:51 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting variable (T_VARIABLE) or '$' G:\code2016\mantou\serve\ribao\cache\templates\2845aac3d852b5660054080aff2fd954.cache.php 8
ERROR - 2016-09-03 13:39:06 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting variable (T_VARIABLE) or '$' G:\code2016\mantou\serve\ribao\cache\templates\2845aac3d852b5660054080aff2fd954.cache.php 8
ERROR - 2016-09-03 13:59:18 --> 钩子调用文件（G:\code2016\mantou\serve\ribao/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-09-03 13:59:45 --> 钩子调用文件（G:\code2016\mantou\serve\ribao/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-09-03 13:59:50 --> 钩子调用文件（G:\code2016\mantou\serve\ribao/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-09-03 13:59:55 --> 钩子调用文件（G:\code2016\mantou\serve\ribao/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-09-03 14:06:45 --> Severity: Error --> Function name must be a string G:\code2016\mantou\serve\ribao\cache\templates\93b73a52ba39f577f6a24e5a50d18a05.cache.php 12
ERROR - 2016-09-03 14:07:05 --> Severity: Error --> Function name must be a string G:\code2016\mantou\serve\ribao\cache\templates\93b73a52ba39f577f6a24e5a50d18a05.cache.php 12
ERROR - 2016-09-03 14:08:34 --> Severity: Error --> Function name must be a string G:\code2016\mantou\serve\ribao\cache\templates\93b73a52ba39f577f6a24e5a50d18a05.cache.php 12
ERROR - 2016-09-03 14:35:07 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ',' or ';' G:\code2016\mantou\serve\ribao\cache\templates\93b73a52ba39f577f6a24e5a50d18a05.cache.php 77
ERROR - 2016-09-03 15:28:28 --> Severity: Parsing Error --> syntax error, unexpected '$return' (T_VARIABLE) G:\code2016\mantou\serve\ribao\cache\templates\93b73a52ba39f577f6a24e5a50d18a05.cache.php 25
ERROR - 2016-09-03 15:28:49 --> Severity: Parsing Error --> syntax error, unexpected '$return' (T_VARIABLE) G:\code2016\mantou\serve\ribao\cache\templates\93b73a52ba39f577f6a24e5a50d18a05.cache.php 25
ERROR - 2016-09-03 15:30:05 --> Severity: Parsing Error --> syntax error, unexpected '$return' (T_VARIABLE) G:\code2016\mantou\serve\ribao\cache\templates\93b73a52ba39f577f6a24e5a50d18a05.cache.php 25
ERROR - 2016-09-03 15:30:06 --> Severity: Parsing Error --> syntax error, unexpected '$return' (T_VARIABLE) G:\code2016\mantou\serve\ribao\cache\templates\93b73a52ba39f577f6a24e5a50d18a05.cache.php 25
ERROR - 2016-09-03 15:32:18 --> Severity: Parsing Error --> syntax error, unexpected '$return' (T_VARIABLE) G:\code2016\mantou\serve\ribao\cache\templates\93b73a52ba39f577f6a24e5a50d18a05.cache.php 25
ERROR - 2016-09-03 15:32:19 --> Severity: Parsing Error --> syntax error, unexpected '$return' (T_VARIABLE) G:\code2016\mantou\serve\ribao\cache\templates\93b73a52ba39f577f6a24e5a50d18a05.cache.php 25
ERROR - 2016-09-03 15:32:19 --> Severity: Parsing Error --> syntax error, unexpected '$return' (T_VARIABLE) G:\code2016\mantou\serve\ribao\cache\templates\93b73a52ba39f577f6a24e5a50d18a05.cache.php 25
ERROR - 2016-09-03 15:32:20 --> Severity: Parsing Error --> syntax error, unexpected '$return' (T_VARIABLE) G:\code2016\mantou\serve\ribao\cache\templates\93b73a52ba39f577f6a24e5a50d18a05.cache.php 25
ERROR - 2016-09-03 15:32:23 --> Severity: Parsing Error --> syntax error, unexpected '$return' (T_VARIABLE) G:\code2016\mantou\serve\ribao\cache\templates\93b73a52ba39f577f6a24e5a50d18a05.cache.php 25
ERROR - 2016-09-03 15:32:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'order by logintime desc limit 5' at line 1 - Invalid query: select * from man_member_login where uid= order by logintime desc limit 5
ERROR - 2016-09-03 15:34:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'order by logintime desc limit 5' at line 1 - Invalid query: select * from man_member_login where uid= order by logintime desc limit 5
ERROR - 2016-09-03 15:34:58 --> Query error: Table 'man_bao.man_man_1_events' doesn't exist - Invalid query: select * from man_man_1_events where id=1 order by logintime desc limit 5
ERROR - 2016-09-03 15:34:59 --> Query error: Table 'man_bao.man_man_1_events' doesn't exist - Invalid query: select * from man_man_1_events where id=1 order by logintime desc limit 5
ERROR - 2016-09-03 15:35:22 --> Query error: Table 'man_bao.man__1_events' doesn't exist - Invalid query: select * from man__1_events where id=1 order by logintime desc limit 5
ERROR - 2016-09-03 15:35:23 --> Query error: Table 'man_bao.man__1_events' doesn't exist - Invalid query: select * from man__1_events where id=1 order by logintime desc limit 5
ERROR - 2016-09-03 15:35:29 --> Query error: Unknown column 'logintime' in 'order clause' - Invalid query: select * from man_1_events where id=1 order by logintime desc limit 5
ERROR - 2016-09-03 15:35:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'desc limit 5' at line 1 - Invalid query: select * from man_1_events where id=1 order  desc limit 5
ERROR - 2016-09-03 15:57:19 --> 钩子调用文件（G:\code2016\mantou\serve\ribao/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-09-03 15:57:25 --> 钩子调用文件（G:\code2016\mantou\serve\ribao/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-09-03 15:57:29 --> 钩子调用文件（G:\code2016\mantou\serve\ribao/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-09-03 15:57:34 --> 钩子调用文件（G:\code2016\mantou\serve\ribao/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-09-03 15:57:38 --> 钩子调用文件（G:\code2016\mantou\serve\ribao/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-09-03 15:57:43 --> 钩子调用文件（G:\code2016\mantou\serve\ribao/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-09-03 15:57:48 --> 钩子调用文件（G:\code2016\mantou\serve\ribao/mantob/hooks/module_hooks.php）的不存在
