<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-09-01 01:54:50 --> Could not find the language line "html-001"
ERROR - 2016-09-01 01:54:50 --> Could not find the language line "html-061"
ERROR - 2016-09-01 10:40:55 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) G:\code2016\mantou\serve\ribao\cache\templates\ae0667d972837deb480500c1128649a4.cache.php 33
ERROR - 2016-09-01 10:41:22 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) G:\code2016\mantou\serve\ribao\cache\templates\ae0667d972837deb480500c1128649a4.cache.php 33
ERROR - 2016-09-01 11:20:31 --> 钩子调用文件（G:\code2016\mantou\serve\ribao/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-09-01 13:49:23 --> 钩子调用文件（G:\code2016\mantou\serve\ribao/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-09-01 16:36:26 --> Query error: Unknown column 'description' in 'field list' - Invalid query: UPDATE `man_1_agenda_category` SET `pid` = 0, `name` = '议题', `show` = '1', `thumb` = '4', `description` = '啊实打实', `letter` = 'y', `dirname` = 'yiti', `setting` = 'a:7:{s:7:\\\"urlrule\\\";s:1:\\\"0\\\";s:4:\\\"edit\\\";s:1:\\\"0\\\";s:7:\\\"linkurl\\\";s:0:\\\"\\\";s:3:\\\"seo\\\";a:4:{s:10:\\\"show_title\\\";s:74:\\\"[第{page}页{join}]{title}{join}{catname}{join}{modname}{join}{SITE_NAME}\\\";s:10:\\\"list_title\\\";s:58:\\\"[第{page}页{join}]{name}{join}{modname}{join}{SITE_NAME}\\\";s:13:\\\"list_keywords\\\";s:0:\\\"\\\";s:16:\\\"list_description\\\";s:0:\\\"\\\";}s:8:\\\"template\\\";a:4:{s:8:\\\"pagesize\\\";s:2:\\\"20\\\";s:4:\\\"show\\\";s:9:\\\"show.html\\\";s:8:\\\"category\\\";s:13:\\\"category.html\\\";s:4:\\\"list\\\";s:9:\\\"list.html\\\";}s:5:\\\"admin\\\";a:0:{}s:6:\\\"member\\\";a:0:{}}', `permission` = ''
WHERE `id` = 8
ERROR - 2016-09-01 17:07:25 --> Severity: Error --> Call to undefined function get_pdirname() G:\code2016\mantou\serve\ribao\cache\templates\c2a741bc80a9abd87012281ac251dea7.cache.php 18
ERROR - 2016-09-01 17:27:49 --> 钩子调用文件（G:\code2016\mantou\serve\ribao/mantob/hooks/module_hooks.php）的不存在
