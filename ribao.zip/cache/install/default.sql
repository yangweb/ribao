INSERT INTO `{dbprefix}field` VALUES(NULL, '名称', 'title', 'Text', 1, 'space', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:4:{s:5:\\"width\\";s:3:\\"400\\";s:5:\\"value\\";s:0:\\"\\";s:9:\\"fieldtype\\";s:7:\\"VARCHAR\\";s:11:\\"fieldlength\\";s:3:\\"255\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"1\\";s:8:\\"required\\";s:1:\\"1\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";N;s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:0:\\"\\";s:4:\\"tips\\";N;s:8:\\"formattr\\";s:34:\\"onblur=\\"get_keywords(\\''keywords\\'');\\"\\";}}', 1);
INSERT INTO `{dbprefix}field` VALUES(NULL, '名称', 'title', 'Text', 2, 'space', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:4:{s:5:\\"width\\";s:3:\\"400\\";s:5:\\"value\\";s:0:\\"\\";s:9:\\"fieldtype\\";s:7:\\"VARCHAR\\";s:11:\\"fieldlength\\";s:3:\\"255\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"1\\";s:8:\\"required\\";s:1:\\"1\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";N;s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:0:\\"\\";s:4:\\"tips\\";N;s:8:\\"formattr\\";s:0:\\"\\";}}', 0);
INSERT INTO `{dbprefix}field` VALUES(NULL, '主题', 'title', 'Text', 3, 'space', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:4:{s:5:\\"width\\";s:3:\\"400\\";s:5:\\"value\\";s:0:\\"\\";s:9:\\"fieldtype\\";s:7:\\"VARCHAR\\";s:11:\\"fieldlength\\";s:3:\\"255\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"1\\";s:8:\\"required\\";s:1:\\"1\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";N;s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:0:\\"\\";s:4:\\"tips\\";N;s:8:\\"formattr\\";s:34:\\"onblur=\\"get_keywords(\\''keywords\\'');\\"\\";}}', 1);
INSERT INTO `{dbprefix}field` VALUES(NULL, '名称', 'title', 'Text', 4, 'space', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:4:{s:5:\\"width\\";s:3:\\"400\\";s:5:\\"value\\";s:0:\\"\\";s:9:\\"fieldtype\\";s:7:\\"VARCHAR\\";s:11:\\"fieldlength\\";s:3:\\"255\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"1\\";s:8:\\"required\\";s:1:\\"1\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";N;s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:0:\\"\\";s:4:\\"tips\\";N;s:8:\\"formattr\\";s:34:\\"onblur=\\"get_keywords(\\''keywords\\'');\\"\\";}}', 1);
INSERT INTO `{dbprefix}field` VALUES(NULL, '内容', 'content', 'Ueditor', 1, 'space', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:6:{s:5:\\"width\\";s:3:\\"90%\\";s:6:\\"height\\";s:3:\\"100\\";s:3:\\"key\\";s:0:\\"\\";s:4:\\"mode\\";s:1:\\"2\\";s:4:\\"tool\\";s:29:\\"\\''bold\\'', \\''italic\\'', \\''underline\\''\\";s:5:\\"value\\";s:0:\\"\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"0\\";s:8:\\"required\\";s:1:\\"1\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";N;s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:0:\\"\\";s:4:\\"tips\\";N;s:8:\\"formattr\\";s:0:\\"\\";}}', 4);
INSERT INTO `{dbprefix}field` VALUES(NULL, '链接地址', 'link', 'Redirect', 2, 'space', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:2:{s:5:\\"width\\";s:3:\\"400\\";s:5:\\"value\\";s:0:\\"\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"0\\";s:8:\\"required\\";s:1:\\"0\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";N;s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:0:\\"\\";s:4:\\"tips\\";N;s:8:\\"formattr\\";s:0:\\"\\";}}', 0);
INSERT INTO `{dbprefix}field` VALUES(NULL, '内容', 'content', 'Ueditor', 3, 'space', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:6:{s:5:\\"width\\";s:3:\\"90%\\";s:6:\\"height\\";s:3:\\"100\\";s:3:\\"key\\";s:0:\\"\\";s:4:\\"mode\\";s:1:\\"2\\";s:4:\\"tool\\";s:29:\\"\\''bold\\'', \\''italic\\'', \\''underline\\''\\";s:5:\\"value\\";s:0:\\"\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"0\\";s:8:\\"required\\";s:1:\\"0\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";N;s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:0:\\"\\";s:4:\\"tips\\";N;s:8:\\"formattr\\";s:0:\\"\\";}}', 4);
INSERT INTO `{dbprefix}field` VALUES(NULL, '图片集', 'image', 'Files', 4, 'space', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:6:{s:5:\\"width\\";s:3:\\"80%\\";s:4:\\"size\\";s:2:\\"10\\";s:5:\\"count\\";s:2:\\"50\\";s:3:\\"ext\\";s:11:\\"gif,png,jpg\\";s:10:\\"uploadpath\\";s:25:\\"{siteid}/photo/{y}{m}{d}/\\";s:3:\\"pan\\";s:1:\\"0\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"0\\";s:8:\\"required\\";s:1:\\"0\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";N;s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:0:\\"\\";s:4:\\"tips\\";N;s:8:\\"formattr\\";s:0:\\"\\";}}', 3);
INSERT INTO `{dbprefix}field` VALUES(NULL, '简介', 'content', 'Ueditor', 4, 'space', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:6:{s:5:\\"width\\";s:3:\\"90%\\";s:6:\\"height\\";s:3:\\"100\\";s:3:\\"key\\";s:0:\\"\\";s:4:\\"mode\\";s:1:\\"2\\";s:4:\\"tool\\";s:29:\\"\\''bold\\'', \\''italic\\'', \\''underline\\''\\";s:5:\\"value\\";s:0:\\"\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"0\\";s:8:\\"required\\";s:1:\\"0\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";N;s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:0:\\"\\";s:4:\\"tips\\";N;s:8:\\"formattr\\";s:0:\\"\\";}}', 5);
INSERT INTO `{dbprefix}field` VALUES(NULL, '主题', 'title', 'Text', 5, 'space', 1, 1, 1, 1, 1, 0, 'a:2:{s:6:\\"option\\";a:3:{s:5:\\"width\\";i:400;s:9:\\"fieldtype\\";s:7:\\"VARCHAR\\";s:11:\\"fieldlength\\";s:3:\\"255\\";}s:8:\\"validate\\";a:4:{s:3:\\"xss\\";i:1;s:8:\\"required\\";i:1;s:4:\\"tips\\";N;s:9:\\"errortips\\";N;}}', 0);
INSERT INTO `{dbprefix}field` VALUES(NULL, '图片', 'image', 'File', 5, 'space', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:4:{s:4:\\"size\\";s:2:\\"10\\";s:3:\\"ext\\";s:11:\\"gif,png,jpg\\";s:10:\\"uploadpath\\";s:0:\\"\\";s:3:\\"pan\\";s:1:\\"0\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"0\\";s:8:\\"required\\";s:1:\\"0\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";N;s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:0:\\"\\";s:4:\\"tips\\";N;s:8:\\"formattr\\";s:0:\\"\\";}}', 0);
INSERT INTO `{dbprefix}field` VALUES(NULL, '链接地址', 'link', 'Redirect', 5, 'space', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:2:{s:5:\\"width\\";s:3:\\"400\\";s:5:\\"value\\";s:0:\\"\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"0\\";s:8:\\"required\\";s:1:\\"0\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";N;s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:0:\\"\\";s:4:\\"tips\\";N;s:8:\\"formattr\\";s:0:\\"\\";}}', 0);
INSERT INTO `{dbprefix}field` VALUES(NULL, '关键字', 'keywords', 'Text', 1, 'space', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:4:{s:5:\\"width\\";s:3:\\"400\\";s:5:\\"value\\";s:0:\\"\\";s:9:\\"fieldtype\\";s:7:\\"VARCHAR\\";s:11:\\"fieldlength\\";s:3:\\"255\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"1\\";s:8:\\"required\\";s:1:\\"0\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";N;s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:0:\\"\\";s:4:\\"tips\\";s:43:\\"多个关键字以小写分号“,”分隔\\";s:8:\\"formattr\\";s:0:\\"\\";}}', 2);
INSERT INTO `{dbprefix}field` VALUES(NULL, '描述', 'description', 'Textarea', 1, 'space', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:3:{s:5:\\"width\\";s:3:\\"500\\";s:6:\\"height\\";s:2:\\"60\\";s:5:\\"value\\";s:0:\\"\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"1\\";s:8:\\"required\\";s:1:\\"0\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";N;s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:12:\\"man_clearhtml\\";s:4:\\"tips\\";N;s:8:\\"formattr\\";s:0:\\"\\";}}', 3);
INSERT INTO `{dbprefix}field` VALUES(NULL, '关键字', 'keywords', 'Text', 3, 'space', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:4:{s:5:\\"width\\";s:3:\\"400\\";s:5:\\"value\\";s:0:\\"\\";s:9:\\"fieldtype\\";s:7:\\"VARCHAR\\";s:11:\\"fieldlength\\";s:3:\\"255\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"1\\";s:8:\\"required\\";s:1:\\"0\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";N;s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:0:\\"\\";s:4:\\"tips\\";s:43:\\"多个关键字以小写分号“,”分隔\\";s:8:\\"formattr\\";s:0:\\"\\";}}', 2);
INSERT INTO `{dbprefix}field` VALUES(NULL, '描述', 'description', 'Textarea', 3, 'space', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:3:{s:5:\\"width\\";s:3:\\"400\\";s:6:\\"height\\";s:2:\\"60\\";s:5:\\"value\\";s:0:\\"\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"1\\";s:8:\\"required\\";s:1:\\"0\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";N;s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:12:\\"man_clearhtml\\";s:4:\\"tips\\";N;s:8:\\"formattr\\";s:0:\\"\\";}}', 3);
INSERT INTO `{dbprefix}field` VALUES(NULL, '关键字', 'keywords', 'Text', 4, 'space', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:4:{s:5:\\"width\\";s:3:\\"400\\";s:5:\\"value\\";s:0:\\"\\";s:9:\\"fieldtype\\";s:7:\\"VARCHAR\\";s:11:\\"fieldlength\\";s:3:\\"255\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"1\\";s:8:\\"required\\";s:1:\\"0\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";N;s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:0:\\"\\";s:4:\\"tips\\";s:43:\\"多个关键字以小写分号“,”分隔\\";s:8:\\"formattr\\";s:0:\\"\\";}}', 2);
INSERT INTO `{dbprefix}field` VALUES(NULL, '描述', 'description', 'Textarea', 4, 'space', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:3:{s:5:\\"width\\";s:3:\\"400\\";s:6:\\"height\\";s:2:\\"60\\";s:5:\\"value\\";s:0:\\"\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"1\\";s:8:\\"required\\";s:1:\\"0\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";N;s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:12:\\"man_clearhtml\\";s:4:\\"tips\\";N;s:8:\\"formattr\\";s:0:\\"\\";}}', 4);

INSERT INTO `{dbprefix}field` VALUES(NULL, '名称', 'name', 'Text', 0, 'spacetable', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:3:{s:5:\\"width\\";i:300;s:9:\\"fieldtype\\";s:7:\\"VARCHAR\\";s:11:\\"fieldlength\\";s:3:\\"255\\";}s:8:\\"validate\\";a:4:{s:3:\\"xss\\";i:1;s:8:\\"required\\";i:1;s:4:\\"tips\\";N;s:9:\\"errortips\\";N;}}', 0);
INSERT INTO `{dbprefix}field` VALUES(NULL, 'Logo', 'logo', 'File', 0, 'spacetable', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:3:{s:4:\\"size\\";s:1:\\"2\\";s:3:\\"ext\\";s:11:\\"jpg,gif,png\\";s:10:\\"uploadpath\\";s:0:\\"\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"0\\";s:8:\\"required\\";s:1:\\"0\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";s:0:\\"\\";s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:0:\\"\\";s:4:\\"tips\\";s:0:\\"\\";s:8:\\"formattr\\";s:0:\\"\\";}}', 0);
INSERT INTO `{dbprefix}field` VALUES(NULL, '空间简介', 'introduction', 'Ueditor', 0, 'spacetable', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:5:{s:5:\\"width\\";s:3:\\"90%\\";s:6:\\"height\\";s:3:\\"200\\";s:4:\\"mode\\";s:1:\\"2\\";s:4:\\"tool\\";s:29:\\"\\''bold\\'', \\''italic\\'', \\''underline\\''\\";s:5:\\"value\\";s:0:\\"\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"0\\";s:8:\\"required\\";s:1:\\"0\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";s:0:\\"\\";s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:0:\\"\\";s:4:\\"tips\\";s:0:\\"\\";s:8:\\"formattr\\";s:0:\\"\\";}}', 0);
INSERT INTO `{dbprefix}field` VALUES(NULL, 'SEO标题', 'title', 'Text', 0, 'spacetable', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:4:{s:5:\\"width\\";s:3:\\"400\\";s:5:\\"value\\";s:0:\\"\\";s:9:\\"fieldtype\\";s:0:\\"\\";s:11:\\"fieldlength\\";s:0:\\"\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"0\\";s:8:\\"required\\";s:1:\\"0\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";s:0:\\"\\";s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:0:\\"\\";s:4:\\"tips\\";s:0:\\"\\";s:8:\\"formattr\\";s:0:\\"\\";}}', 0);
INSERT INTO `{dbprefix}field` VALUES(NULL, 'SEO关键字', 'keywords', 'Text', 0, 'spacetable', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:4:{s:5:\\"width\\";s:3:\\"400\\";s:5:\\"value\\";s:0:\\"\\";s:9:\\"fieldtype\\";s:0:\\"\\";s:11:\\"fieldlength\\";s:0:\\"\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"0\\";s:8:\\"required\\";s:1:\\"0\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";s:0:\\"\\";s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:0:\\"\\";s:4:\\"tips\\";s:0:\\"\\";s:8:\\"formattr\\";s:0:\\"\\";}}', 0);
INSERT INTO `{dbprefix}field` VALUES(NULL, 'SEO描述信息', 'description', 'Textarea', 0, 'spacetable', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:3:{s:5:\\"width\\";s:3:\\"500\\";s:6:\\"height\\";s:3:\\"100\\";s:5:\\"value\\";s:0:\\"\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"0\\";s:8:\\"required\\";s:1:\\"0\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";s:0:\\"\\";s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:0:\\"\\";s:4:\\"tips\\";s:0:\\"\\";s:8:\\"formattr\\";s:0:\\"\\";}}', 0);
INSERT INTO `{dbprefix}field` VALUES(NULL, '第三方代码', 'code', 'Textarea', 0, 'spacetable', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:3:{s:5:\\"width\\";s:3:\\"500\\";s:6:\\"height\\";s:3:\\"100\\";s:5:\\"value\\";s:0:\\"\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"0\\";s:8:\\"required\\";s:1:\\"0\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";s:0:\\"\\";s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:0:\\"\\";s:4:\\"tips\\";s:0:\\"\\";s:8:\\"formattr\\";s:0:\\"\\";}}', 0);
INSERT INTO `{dbprefix}field` VALUES(NULL, '底部信息', 'footer', 'Ueditor', 0, 'spacetable', 1, 1, 1, 1, 0, 0, 'a:2:{s:6:\\"option\\";a:5:{s:5:\\"width\\";s:3:\\"90%\\";s:6:\\"height\\";s:3:\\"200\\";s:4:\\"mode\\";s:1:\\"2\\";s:4:\\"tool\\";s:29:\\"\\''bold\\'', \\''italic\\'', \\''underline\\''\\";s:5:\\"value\\";s:0:\\"\\";}s:8:\\"validate\\";a:9:{s:3:\\"xss\\";s:1:\\"0\\";s:8:\\"required\\";s:1:\\"0\\";s:7:\\"pattern\\";s:0:\\"\\";s:9:\\"errortips\\";s:0:\\"\\";s:6:\\"isedit\\";s:1:\\"0\\";s:5:\\"check\\";s:0:\\"\\";s:6:\\"filter\\";s:0:\\"\\";s:4:\\"tips\\";s:0:\\"\\";s:8:\\"formattr\\";s:0:\\"\\";}}', 0);



REPLACE INTO `{dbprefix}space_model` VALUES(1, '文章', 'news', 'a:8:{s:3:\\"3_1\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"1\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"3_2\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"2\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"3_3\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"3\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"3_4\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"4\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"4_5\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"5\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"4_6\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"6\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"4_7\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"7\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"4_8\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"8\\";s:5:\\"score\\";s:0:\\"\\";}}');
REPLACE INTO `{dbprefix}space_model` VALUES(2, '外链', 'link', 'a:8:{s:3:\\"3_1\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"1\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"3_2\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"2\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"3_3\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"3\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"3_4\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"4\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"4_5\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"5\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"4_6\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"6\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"4_7\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"7\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"4_8\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"8\\";s:5:\\"score\\";s:0:\\"\\";}}');
REPLACE INTO `{dbprefix}space_model` VALUES(3, '日志', 'log', 'a:8:{s:3:\\"3_1\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"1\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"3_2\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"2\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"3_3\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"3\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"3_4\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"4\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"4_5\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"5\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"4_6\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"6\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"4_7\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"7\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"4_8\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"8\\";s:5:\\"score\\";s:0:\\"\\";}}');
REPLACE INTO `{dbprefix}space_model` VALUES(4, '相册', 'photo', 'a:8:{s:3:\\"3_1\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"1\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"3_2\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"2\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"3_3\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"3\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"3_4\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"4\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"4_5\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"1\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"4_6\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"2\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"4_7\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"3\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"4_8\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:1:\\"4\\";s:5:\\"score\\";s:0:\\"\\";}}');
REPLACE INTO `{dbprefix}space_model` VALUES(5, '幻灯', 'slides', 'a:8:{s:3:\\"3_1\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:0:\\"\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"3_2\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:0:\\"\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"3_3\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:0:\\"\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"3_4\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:0:\\"\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"4_5\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:0:\\"\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"4_6\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:0:\\"\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"4_7\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:0:\\"\\";s:5:\\"score\\";s:0:\\"\\";}s:3:\\"4_8\\";a:3:{s:3:\\"use\\";s:1:\\"1\\";s:10:\\"experience\\";s:0:\\"\\";s:5:\\"score\\";s:0:\\"\\";}}');

DROP TABLE IF EXISTS `{dbprefix}space_link`;
CREATE TABLE IF NOT EXISTS `{dbprefix}space_link` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL COMMENT '栏目id',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `uid` mediumint(8) unsigned NOT NULL COMMENT '作者uid',
  `author` varchar(50) NOT NULL COMMENT '作者',
  `hits` int(10) unsigned NOT NULL COMMENT '点击量',
  `status` tinyint(1) unsigned NOT NULL COMMENT '审核状态',
  `inputtime` int(10) unsigned NOT NULL COMMENT '录入时间',
  `updatetime` int(10) unsigned NOT NULL COMMENT '更新时间',
  `displayorder` tinyint(3) NOT NULL DEFAULT '0',
  `link` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `hits` (`hits`),
  KEY `catid` (`catid`),
  KEY `status` (`status`),
  KEY `inputtime` (`inputtime`),
  KEY `updatetime` (`updatetime`),
  KEY `displayorder` (`displayorder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会员空间外链模型表' AUTO_INCREMENT=1 ;

DROP TABLE IF EXISTS `{dbprefix}space_log`;
CREATE TABLE IF NOT EXISTS `{dbprefix}space_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL COMMENT '栏目id',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `keywords` varchar(255) DEFAULT NULL COMMENT '关键词',
  `description` text DEFAULT NULL COMMENT '描述',
  `uid` mediumint(8) unsigned NOT NULL COMMENT '作者uid',
  `author` varchar(50) NOT NULL COMMENT '作者',
  `hits` int(10) unsigned NOT NULL COMMENT '点击量',
  `status` tinyint(1) unsigned NOT NULL COMMENT '审核状态',
  `inputtime` int(10) unsigned NOT NULL COMMENT '录入时间',
  `updatetime` int(10) unsigned NOT NULL COMMENT '更新时间',
  `displayorder` tinyint(3) NOT NULL DEFAULT '0',
  `content` mediumtext,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `hits` (`hits`),
  KEY `catid` (`catid`),
  KEY `status` (`status`),
  KEY `inputtime` (`inputtime`),
  KEY `updatetime` (`updatetime`),
  KEY `displayorder` (`displayorder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会员空间日志模型表' AUTO_INCREMENT=1 ;

DROP TABLE IF EXISTS `{dbprefix}space_news`;
CREATE TABLE IF NOT EXISTS `{dbprefix}space_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL COMMENT '栏目id',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `keywords` varchar(255) DEFAULT NULL COMMENT '关键词',
  `description` text DEFAULT NULL COMMENT '描述',
  `uid` mediumint(8) unsigned NOT NULL COMMENT '作者uid',
  `author` varchar(50) NOT NULL COMMENT '作者',
  `hits` int(10) unsigned NOT NULL COMMENT '点击量',
  `status` tinyint(1) unsigned NOT NULL COMMENT '审核状态',
  `inputtime` int(10) unsigned NOT NULL COMMENT '录入时间',
  `updatetime` int(10) unsigned NOT NULL COMMENT '更新时间',
  `displayorder` tinyint(3) NOT NULL DEFAULT '0',
  `content` mediumtext,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `hits` (`hits`),
  KEY `catid` (`catid`),
  KEY `status` (`status`),
  KEY `inputtime` (`inputtime`),
  KEY `updatetime` (`updatetime`),
  KEY `displayorder` (`displayorder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会员空间单页模型表' AUTO_INCREMENT=1 ;



-- DROP TABLE IF EXISTS `{dbprefix}1_form_message`;
-- CREATE TABLE IF NOT EXISTS `{dbprefix}1_form_message` (
--   `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
--   `title` varchar(255) NOT NULL COMMENT '主题名字',
--   `phone` varchar(255) NOT NULL COMMENT '联系方式',
--   `address` varchar(255) NOT NULL COMMENT '联系地址',
--   `count` varchar(255) NOT NULL COMMENT '主题内容',
--   `inputtime` int(10) unsigned NOT NULL COMMENT '录入时间',
--   `displayorder` tinyint(3) NOT NULL DEFAULT '0',
--   PRIMARY KEY (`id`),
--   KEY `title` (`title`),
--   KEY `phone` (`phone`),
--   KEY `address` (`address`),
--   KEY `count` (`count`),
--   KEY `inputtime` (`inputtime`),
--   KEY `displayorder` (`displayorder`)
-- ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='留言表单' AUTO_INCREMENT=1;



DROP TABLE IF EXISTS `{dbprefix}space_photo`;
CREATE TABLE IF NOT EXISTS `{dbprefix}space_photo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL COMMENT '栏目id',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `keywords` varchar(255) DEFAULT NULL COMMENT '关键词',
  `description` text DEFAULT NULL COMMENT '描述',
  `uid` mediumint(8) unsigned NOT NULL COMMENT '作者uid',
  `author` varchar(50) NOT NULL COMMENT '作者',
  `hits` int(10) unsigned NOT NULL COMMENT '点击量',
  `status` tinyint(1) unsigned NOT NULL COMMENT '审核状态',
  `inputtime` int(10) unsigned NOT NULL COMMENT '录入时间',
  `updatetime` int(10) unsigned NOT NULL COMMENT '更新时间',
  `displayorder` tinyint(3) NOT NULL DEFAULT '0',
  `image` text,
  `content` mediumtext,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `hits` (`hits`),
  KEY `catid` (`catid`),
  KEY `status` (`status`),
  KEY `inputtime` (`inputtime`),
  KEY `updatetime` (`updatetime`),
  KEY `displayorder` (`displayorder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会员空间相册模型表' AUTO_INCREMENT=1 ;

DROP TABLE IF EXISTS `{dbprefix}space_slides`;
CREATE TABLE IF NOT EXISTS `{dbprefix}space_slides` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL COMMENT '栏目id',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `uid` mediumint(8) unsigned NOT NULL COMMENT '作者uid',
  `author` varchar(50) NOT NULL COMMENT '作者',
  `hits` int(10) unsigned NOT NULL COMMENT '点击量',
  `status` tinyint(1) unsigned NOT NULL COMMENT '审核状态',
  `inputtime` int(10) unsigned NOT NULL COMMENT '录入时间',
  `updatetime` int(10) unsigned NOT NULL COMMENT '更新时间',
  `displayorder` tinyint(3) NOT NULL DEFAULT '0',
  `image` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `hits` (`hits`),
  KEY `catid` (`catid`),
  KEY `status` (`status`),
  KEY `inputtime` (`inputtime`),
  KEY `updatetime` (`updatetime`),
  KEY `displayorder` (`displayorder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会员空间幻灯模型表' AUTO_INCREMENT=1;

REPLACE INTO `{dbprefix}space_slides` (`id`, `catid`, `title`, `uid`, `author`, `hits`, `status`, `inputtime`, `updatetime`, `displayorder`, `image`, `link`) VALUES (1, 7, '应用开放平台', 1, 'admin', 0, 1, 1377949237, 1377949237, 0, 'http://www.montob.com/montob/statics/montob/images/index_banner1.jpg', 'http://store.montob.com'),(2, 7, '群站多语言管理', 1, 'admin', 0, 1, 1377949258, 1377949258, 0, 'http://www.montob.com/montob/statics/montob/images/index_banner2.jpg', 'http://web.montob.com/'),(3, 7, 'mantob 一套神奇的系统', 1, 'admin', 0, 1, 1377949306, 1377949306, 0, 'http://www.montob.com/montob/statics/montob/images/index_banner3.jpg', 'http://www.montob.com/');

REPLACE INTO `{dbprefix}space` (`uid`, `name`, `logo`, `style`, `title`, `keywords`, `description`, `introduction`, `code`, `footer`, `hits`, `status`, `regtime`) VALUES
(1, 'mantob团队', 'http://www.montob.com/member/statics/default/images/logo_new.png', 'default', 'mantob团队-专业技术团队', 'mantob,网站建设,内容管理系统', 'mantob v2（简称v2）是一款开源的跨平台网站内容管理系统，以“实用+好用”为基本产品理念，提供从内容发布、组织、传播、互动和数据挖掘的网站一体化解决方案', '<p>mantob v2（简称v2）是一款开源的跨平台网站内容管理系统，以“实用+好用”为基本产品理念，提供从内容发布、组织、传播、互动和数据挖掘的网站一体化解决方案。系统基于CodeIgniter框架，具有良好扩展性和管理性，可以帮助您在各种操作系统与运行环境中搭建各种网站模型而不需要对复杂繁琐的编程语言有太多的专业知识，系统采用UTF-8编码，采取(语言-代码-程序)两两分离的技术模式，全面使用了模板包与语言包结构，为用户的修改提供方便，网站内容的每一个角落都可以在后台予以管理，是一套非常适合用做系统建站或者进行二次开发的程序核心。</p>', '<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cdiv id=''cnzz_stat_icon_5629330''%3E%3C/div%3E%3Cscript src=''" + cnzz_protocol + "s9.cnzz.com/stat.php%3Fid%3D5629330%26show%3Dpic2'' type=''text/javascript''%3E%3C/script%3E"));</script>', '<p>扣扣咨询：135977378 电子邮箱：mantob@qq.com</p>某某某公司版权所有，ICP备案0000001<p><br /></p>', 888888, 1, 1377949585);


-- REPLACE INTO `{dbprefix}1_form` VALUES (1, '留言板', 'message', 'a:4:{s:4:\\\"post\\\";s:1:\\\"1\\\";s:4:\\\"code\\\";s:1:\\\"0\\\";s:4:\\\"send\\\";s:0:\\\"\\\";s:8:\\\"template\\\";s:0:\\\"\\\";}');
-- REPLACE INTO `{dbprefix}1_form_message` VALUES (1, '胜多负少', '127.0.0.1', 1410844859, 0, '15000003499', '上海市普陀区', '留言内容');
REPLACE INTO `{dbprefix}space_flag` (`flag`, `uid`) VALUES (1, 1), (2, 1);

REPLACE INTO `{dbprefix}space_category_init` VALUES(1, 1, 0, '0', 2, '关于我们', '', 3, 0, 1, '1,2,3');
REPLACE INTO `{dbprefix}space_category_init` VALUES(2, 1, 1, '0,1', 2, '空间简介', '', 3, 0, 0, '2');
REPLACE INTO `{dbprefix}space_category_init` VALUES(3, 1, 1, '0,1', 2, '联系我们', '', 3, 0, 0, '3');
REPLACE INTO `{dbprefix}space_category_init` VALUES(4, 1, 0, '0', 1, '新闻资讯', '', 3, 1, 0, '4');
REPLACE INTO `{dbprefix}space_category_init` VALUES(5, 1, 0, '0', 1, '我的日志', '', 3, 3, 0, '5');
REPLACE INTO `{dbprefix}space_category_init` VALUES(6, 1, 0, '0', 1, '精彩图片', '', 3, 4, 0, '6');
REPLACE INTO `{dbprefix}space_category_init` VALUES(7, 1, 0, '0', 1, '首页幻灯', '', 0, 5, 0, '7');
REPLACE INTO `{dbprefix}space_category_init` VALUES(8, 1, 0, '0', 1, '友情链接', '', 3, 2, 0, '8');
REPLACE INTO `{dbprefix}space_category_init` VALUES(9, 1, 0, '0', 0, '技术支持', 'http://www.montob.com', 3, 0, 0, '9');
REPLACE INTO `{dbprefix}space_category_init` VALUES(10, 2, 0, '0', 2, '关于我们', '', 3, 0, 1, '10,11,12');
REPLACE INTO `{dbprefix}space_category_init` VALUES(11, 2, 10, '0,10', 2, '空间简介', '', 3, 0, 0, '11');
REPLACE INTO `{dbprefix}space_category_init` VALUES(12, 2, 10, '0,10', 2, '联系我们', '', 3, 0, 0, '12');
REPLACE INTO `{dbprefix}space_category_init` VALUES(13, 2, 0, '0', 1, '新闻资讯', '', 3, 1, 0, '13');
REPLACE INTO `{dbprefix}space_category_init` VALUES(14, 2, 0, '0', 1, '我的日志', '', 3, 3, 0, '14');
REPLACE INTO `{dbprefix}space_category_init` VALUES(15, 2, 0, '0', 1, '精彩图片', '', 3, 4, 0, '15');
REPLACE INTO `{dbprefix}space_category_init` VALUES(16, 2, 0, '0', 1, '首页幻灯', '', 0, 5, 0, '16');
REPLACE INTO `{dbprefix}space_category_init` VALUES(17, 2, 0, '0', 1, '友情链接', '', 3, 2, 0, '17');
REPLACE INTO `{dbprefix}space_category_init` VALUES(18, 2, 0, '0', 0, '技术支持', 'http://www.montob.com', 3, 0, 0, '18');
REPLACE INTO `{dbprefix}space_category_init` VALUES(19, 3, 0, '0', 2, '关于我们', '', 3, 0, 1, '19,20,21');
REPLACE INTO `{dbprefix}space_category_init` VALUES(20, 3, 19, '0,19', 2, '空间简介', '', 3, 0, 0, '20');
REPLACE INTO `{dbprefix}space_category_init` VALUES(21, 3, 19, '0,19', 2, '联系我们', '', 3, 0, 0, '21');
REPLACE INTO `{dbprefix}space_category_init` VALUES(22, 3, 0, '0', 1, '新闻资讯', '', 3, 1, 0, '22');
REPLACE INTO `{dbprefix}space_category_init` VALUES(23, 3, 0, '0', 1, '我的日志', '', 3, 3, 0, '23');
REPLACE INTO `{dbprefix}space_category_init` VALUES(24, 3, 0, '0', 1, '精彩图片', '', 3, 4, 0, '24');
REPLACE INTO `{dbprefix}space_category_init` VALUES(25, 3, 0, '0', 1, '首页幻灯', '', 0, 5, 0, '25');
REPLACE INTO `{dbprefix}space_category_init` VALUES(26, 3, 0, '0', 1, '友情链接', '', 3, 2, 0, '26');
REPLACE INTO `{dbprefix}space_category_init` VALUES(27, 3, 0, '0', 0, '技术支持', 'http://www.montob.com', 3, 0, 0, '27');
REPLACE INTO `{dbprefix}space_category_init` VALUES(28, 4, 0, '0', 2, '关于我们', '', 3, 0, 1, '28,29,30');
REPLACE INTO `{dbprefix}space_category_init` VALUES(29, 4, 28, '0,28', 2, '空间简介', '', 3, 0, 0, '29');
REPLACE INTO `{dbprefix}space_category_init` VALUES(30, 4, 28, '0,28', 2, '联系我们', '', 3, 0, 0, '30');
REPLACE INTO `{dbprefix}space_category_init` VALUES(31, 4, 0, '0', 1, '新闻资讯', '', 3, 1, 0, '31');
REPLACE INTO `{dbprefix}space_category_init` VALUES(32, 4, 0, '0', 1, '我的日志', '', 3, 3, 0, '32');
REPLACE INTO `{dbprefix}space_category_init` VALUES(33, 4, 0, '0', 1, '精彩图片', '', 3, 4, 0, '33');
REPLACE INTO `{dbprefix}space_category_init` VALUES(34, 4, 0, '0', 1, '首页幻灯', '', 0, 5, 0, '34');
REPLACE INTO `{dbprefix}space_category_init` VALUES(35, 4, 0, '0', 1, '友情链接', '', 3, 2, 0, '35');
REPLACE INTO `{dbprefix}space_category_init` VALUES(36, 4, 0, '0', 0, '技术支持', 'http://www.montob.com', 3, 0, 0, '36');
