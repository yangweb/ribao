<figure class="placeholder small">
<img class="image" alt="" src="<?php echo man_thumb($t['thumb']); ?>" alt="<?php echo $t['title']; ?>" />
<img class="tiny-fallback" src="<?php echo man_thumb($t['thumb'],97,72); ?>" alt="<?php echo $t['title']; ?>" />
</figure>