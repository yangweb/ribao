<div id="cookie-policy" class="cookie-policy">
    <div class="row">
        <div class="small-12 columns cookie-policy__container">
            <div id="cookie-policy-dismiss" class="cookie-policy__dismiss"></div>
            <div class="cookie-policy__message">我们正使用cookies为您提供浏览我们网站的最佳体验。如需继续浏览我们的网页，您需同意我们继续使用cookies</div>
        </div>
    </div>
</div>