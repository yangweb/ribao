<div class="agenda meganav-content__description">
    <div class="row">
        <div class="small-5 columns subpane-navigation">
            <span class="subpane-navigation__item" data-subpane="global"><?php echo $ci->get_cache('module-1-agenda', 'category', 5, 'name'); ?>性</span>
            <span class="subpane-navigation__item" data-subpane="regional"><?php echo $ci->get_cache('module-1-agenda', 'category', 6, 'name'); ?>性</span>
            <span class="subpane-navigation__item" data-subpane="industry"><?php echo $ci->get_cache('module-1-agenda', 'category', 7, 'name'); ?>性</span>
        </div>
        <div class="small-7 columns description">
            <?php echo man_block(4); ?>
        </div>
    </div>
</div>